package com.project.SMART.WASTE.MANAGEMENT.SYSTEM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartWasteManagementSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(SmartWasteManagementSystemApplication.class, args);
	}
}

