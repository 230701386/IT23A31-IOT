package com.project.SMART.WASTE.MANAGEMENT.SYSTEM.DTO;

public class NotificationMessage {
    private String message;
    private String type;


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
